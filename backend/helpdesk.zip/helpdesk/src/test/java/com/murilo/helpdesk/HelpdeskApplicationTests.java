package com.murilo.helpdesk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelpdeskApplicationTests {

	@Test
	void contextLoads() {
	}

}
